# NilePhytoDock Studio v1.0.2

Developed by **Ahmed G Soliman** and **Malak Taha**. Maintenance update to the existing Windows application; v1.0.0 remains the first official public release.

This release packages the improvements made after v1.0.1 and addresses workstation resource use, background task concurrency, cancellation and window closing. Molecular views load on demand, hidden views suspend, and the separate 3D window reuses one scene. Detailed results and rankings load asynchronously. Existing visualizations and exports are retained.

The scientific seed, library contents, native P2Rank/Smina/Java versions and docking/contact algorithms are unchanged. One Windows Setup file includes the runtime and engines. Documentation remains in the external Documentation folder; the interface is English.

[English guide](docs/Release_v1.0.2_EN.md) · [Update validation](docs/Validation_v1.0.2.md) · [Source access](SOURCE_ACCESS.md) · [Licensing audit](LICENSE_AUDIT.md)

[Windows product/download page](https://github.com/ahmedGSoliman99/NilePhytoDock-Studio) · [Mandatory corresponding source](https://github.com/ahmedGSoliman99/NilePhytoDock-Source)

Historical releases, source archives and validation records retain their original version numbers.
