# NilePhytoDock Studio release history

## v1.0.1 — coordinate retrieval and molecular figures

- Normalize pasted PDB IDs, extended IDs and structure links; validate downloaded coordinates and fall back to mmCIF/PDBe.
- Add explicit camera views, rotation/tilt controls and resolution-scaled visible 3D labels; preserve the current camera during export. Show the full protein and ligand by default, reuse validated covalent bonds at visible contact endpoints, provide explicit ring-centroid guides and retain computed pocket surfaces in exports.
- Provide a prominent Save 2D figure button, larger canvas and typed circular residue maps.
- Add the requested oil-colored Docking Network with an explicit score-to-radius mapping, aligned callouts and all six existing exports.
- Draw shared conventional functional groups with SMARTS-verified highlighted examples from the analyzed compounds.
- Preserve the seed library, native engines, scientific classifications and all historical releases.

## v1.0.0 — first official public release

- One Windows setup download with bundled Python, Qt, scientific dependencies, Java, P2Rank and Smina; installed libraries remain replaceable.
- Scientific Charts now contains only Bubble Plot, Docking Heatmap and Interaction Matrix. One chart is queried and rendered at a time, using saved scores and detected contacts. Numerical/figure exports remain available.
- Consistent v1.0.0 branding and Windows metadata, original logo, English interface and external English documentation.
- A clean public product/download repository plus separate corresponding-source access. Original development history and previous validation records are preserved.

Existing molecular calculations, 2D/3D functionality and library content are retained. See docs/Packaging_Validation_v1.0.0.md for the release-specific test scope and packaging measurements.

# Changelog

## v1.0.2

Package the existing application with bounded background work, deferred molecular viewers, one shared 3D scene, asynchronous result queries, reliable cancellation/closing and explicit cache-use messages. Existing algorithms, library records and historical validation remain unchanged. See `docs/Release_Notes_v1.0.2.md`.

## 0.6.1 — 2026-10-29

- Public repository/downloads verified without authentication.
- Oil-first results: one best pose per chemical identity, explicit receptor/site/protocol, source-sample selector and concise best-compound exports.
- Separate functional-group page for the top-scoring oil compounds, retained cutoff ties, unique-identity counts and verified participation distinct from presence.
- Dedicated 3D page and independent maximized window, direct opening from results, F11 uninterrupted canvas and Esc restoration.
- Clear ligand focus and whole-protein overview. Detailed docking and molecular analyses remain secondary views.
- Five new scientific summary regression tests plus native UI/layout/fullscreen and frozen integration checks.


## 0.6.0 — 2026-10-29

- Minimal dashboard counts distinct botanical oils and verified chemical structures from SQLite.
- Versioned, independently verified atom/feature geometry and archived interaction reanalysis.
- Classic/Circular/Functional group 2D diagrams, independent residue colors and shared interaction palette.
- Offline 3D representation, surface, color, label, focus and high-resolution export controls.
- Sixteen data-driven charts with bubble-area choices, filters, multiple membership and tabular exports.
- Expanded primary-literature pack: 31 new profiles and 496 observations; 57 oils, 119 profiles and 2109 observations overall, preserving preceding raw records.
- Twelve qualified historical botanical evaluations and five preparation categories; fixed-lipid pool and derivatization gates.
- Atom-centred SMARTS participation, independent Morgan/Tanimoto and site Jaccard similarity, clusters and scaffold-controlled exploratory statistics.
- Multi-project save isolation, analysis-history retention and portable project relocation.
- Actual 3PTB/BEN charged/neutral controls and botanical case study with 1917 independently verified contacts; no-alignment reference RMSD about 0.39 Angstrom.
- 56 automated tests; frozen Windows P2Rank/Smina integration, native 3D/Plotly and external English case/summary documentation.
- Stricter E/Z identity gate and InChIKey-based percentile/duplicate handling.
- English-only interface and external English PDF/DOCX guides, source observations in reports.
- Updated icon resources, Windows branding, source/build/release verification and GitHub distribution.

Original working data and earlier release artifacts are preserved.
