# NilePhytoDock Studio workspace

## Use or share the application

Open `release/NilePhytoDock-v1.0.2-Setup.exe` to install or share the current Windows release. The installed application is in `%LOCALAPPDATA%/Programs/NilePhytoDockStudio`.

`release` contains the current installer, release notes and checksum. `release/source_access` holds the current and historical corresponding-source archives required for license access; these are optional for researchers installing the application.

## Retained project files

| Location | Purpose |
| --- | --- |
| `app`, `database`, `scientific`, `visualization`, `reporting` | Original application source |
| `data/nilephytodock.sqlite` | Original scientific seed catalog |
| `data/source_documents` | Canonical original Word datasets and combined CSV; identical root-level duplicates were removed |
| `data/compound_library` | Prepared molecular library |
| `app/resources/brand` | Original logo and Windows icons |
| `data/literature` | Scientific source manifests and literature evidence |
| `data/backups` | Preserved database backups |
| `data/validation`, `validation` | Preserved calculations, case studies and release verification records |
| `docs` | Current English guide, methodology and historical documentation |
| `docs/archive/releases` | Historical release notes, checksums and release manifests |
| `external_tools` | Original P2Rank, Java, Smina and mandatory licenses/source inputs |
| `build` | Build specifications, installer source and build scripts |
| `tests`, `tools` | Tests and development utilities |
| `public_site` | Product-page and source-access repository checkouts |
| `.git`, `.venv` | Development history and the tested Python environment |

The duplicate root logo is retained canonically as `app/resources/brand/NilePhytoDock-logo.png`. Utilities and CSV tests use the canonical input locations.

Generated `dist*`, PyInstaller work directories, staging copies, old Windows packages and incomplete downloads can be regenerated and have been removed. A future build recreates its output directories. The published v1.0.0 installer and scientific library have not been rebuilt or modified by this cleanup.

The subsequent v1.0.1 maintenance build recreates only its current staging and build outputs. Its validation remains historical; the original v1.0.0 installer, corresponding source and validation retain their original identity.

The v1.0.2 installer is the current download. Current generated build outputs can be regenerated; required source-access archives are retained.

Researcher-selected study folders and the working database under `%LOCALAPPDATA%/NilePhytoDock` remain in their original locations. Keep complete study folders together so saved paths and molecular files continue to work.
