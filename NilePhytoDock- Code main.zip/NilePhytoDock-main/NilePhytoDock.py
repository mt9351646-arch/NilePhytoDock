from app.resource_policy import configure_environment
configure_environment()
from app.main import main
if __name__=='__main__':
    raise SystemExit(main())
